import cv2
import random
import colorsys
import numpy as np


class PrePost():
    def __init__(self, 
                 classes_path='model_data/classes.txt', 
                 anchors_path='model_data/anchors.txt',
                 input_shape=[640, 640], 
                 letterbox_image=True, 
                 confidence=0.5, 
                 nms_iou=0.45, 
                 anchors_mask = [[0,1,2], [3,4,5], [6,7,8]]):
        super(PrePost, self).__init__()
        self.class_names, self.num_classes  = self.get_classes(classes_path)
        self.anchors, self.num_anchors      = self.get_anchors(anchors_path)
        # print(self.anchors)

        self.bbox_attrs     = 5 + self.num_classes
        self.input_shape    = input_shape
        self.anchors_mask   = anchors_mask
        self.confidence     = confidence
        self.nms_iou        = nms_iou
        self.letterbox_image = letterbox_image

        self.stride = 32

        self.make_colors()
       
    
    def make_colors(self):
        hsv_tuples = [(1.0 * x / self.num_classes, 1., 1.) for x in range(self.num_classes)]
        self.colors = list(map(lambda x: colorsys.hsv_to_rgb(*x), hsv_tuples))
        self.colors = list(map(lambda x: 
                        (int(x[0] * 255), int(x[1] * 255), int(x[2] * 255)), 
                        self.colors))
        random.seed(0)
        random.shuffle(self.colors)
        random.seed(None)

    def get_classes(self, classes_path):
        with open(classes_path, encoding='utf-8') as f:
            class_names = f.readlines()
        class_names = [c.strip() for c in class_names]
        return class_names, len(class_names)
    
    def get_anchors(self, anchors_path):
        '''loads the anchors from a file'''
        with open(anchors_path, encoding='utf-8') as f:
            anchors = f.readline()
        anchors = [float(x) for x in anchors.split(',')]
        anchors = np.array(anchors).reshape(-1, 2)
        return anchors, len(anchors)

    def letterbox(self, im, new_shape=(640, 640), color=(114, 114, 114), auto=False, scaleFill=False, scaleup=True, stride=32):
        # Resize and pad image while meeting stride-multiple constraints
        shape = im.shape[:2]  # current shape [height, width]
        if isinstance(new_shape, int):
            new_shape = (new_shape, new_shape)

        # Scale ratio (new / old)
        r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
        if not scaleup:  # only scale down, do not scale up (for better val mAP)
            r = min(r, 1.0)

        # Compute padding
        ratio = r, r  # width, height ratios
        new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
        dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding
        if auto:  # minimum rectangle
            dw, dh = np.mod(dw, stride), np.mod(dh, stride)  # wh padding
        elif scaleFill:  # stretch
            dw, dh = 0.0, 0.0
            new_unpad = (new_shape[1], new_shape[0])
            ratio = new_shape[1] / shape[1], new_shape[0] / shape[0]  # width, height ratios

        dw /= 2  # divide padding into 2 sides
        dh /= 2

        if shape[::-1] != new_unpad:  # resize
            im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
        top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
        left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
        im = cv2.copyMakeBorder(im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)  # add border

        self.ratio =ratio
        self.dw = dw
        self.dh = dh

        return im, ratio, (dw, dh)
    
    def preprocess(self, image):
        input_size = self.input_shape
        letterbox_image = self.letterbox_image
              
        # image = np.array(image)
        if letterbox_image:
            new_image = self.letterbox(image, input_size, stride=self.stride)[0]  # padded resize
        else:
            # 获得输出的shape
            if isinstance(input_size, int):
                input_size    = (input_size, input_size)
            new_image = cv2.resize(image, input_size)
        
        # BGR to RGB
        new_image = cv2.cvtColor(new_image, cv2.COLOR_BGR2RGB)

        img_data = np.float32(new_image)  # uint8 to fp16/32
        img_data = img_data / 255.0  # 0 - 255 to 0.0 - 1.0

        # # HWC to CHW
        # image_data = np.transpose(img_data, (2, 0, 1))
        # # image_data = image_data[::-1]
        # image_data  = np.expand_dims(image_data, 0)

        # self.ratio = r

        return img_data
      
    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def xywh2xyxy(self, x):
        # Convert [x, y, w, h] to [x1, y1, x2, y2]
        y = np.copy(x)
        y[:, 0] = x[:, 0] - x[:, 2] / 2  # top left x
        y[:, 1] = x[:, 1] - x[:, 3] / 2  # top left y
        y[:, 2] = x[:, 0] + x[:, 2] / 2  # bottom right x
        y[:, 3] = x[:, 1] + x[:, 3] / 2  # bottom right y
        return y

    def process(self, input, mask, anchors, img_size):

        anchors = [anchors[i] for i in mask]

        grid_h, grid_w = map(int, input.shape[0:2])

        box_confidence = self.sigmoid(input[..., 4])
        box_confidence = np.expand_dims(box_confidence, axis=-1)

        box_class_probs = self.sigmoid(input[..., 5:])

        box_xy = self.sigmoid(input[..., :2])*2 - 0.5

        col = np.tile(np.arange(0, grid_w), grid_w).reshape(-1, grid_w)
        row = np.tile(np.arange(0, grid_h).reshape(-1, 1), grid_h)
        col = col.reshape(grid_h, grid_w, 1, 1).repeat(3, axis=-2)
        row = row.reshape(grid_h, grid_w, 1, 1).repeat(3, axis=-2)
        grid = np.concatenate((col, row), axis=-1)
        box_xy += grid
        box_xy *= int(img_size/grid_h)

        box_wh = pow(self.sigmoid(input[..., 2:4])*2, 2)
        box_wh = box_wh * anchors

        box = np.concatenate((box_xy, box_wh), axis=-1)

        return box, box_confidence, box_class_probs

    def filter_boxes(self, boxes, box_confidences, box_class_probs):
        """Filter boxes with box threshold. It's a bit different with origin yolov5 post process!

        # Arguments
            boxes: ndarray, boxes of objects.
            box_confidences: ndarray, confidences of objects.
            box_class_probs: ndarray, class_probs of objects.

        # Returns
            boxes: ndarray, filtered boxes.
            classes: ndarray, classes for boxes.
            scores: ndarray, scores for boxes.
        """
        boxes = boxes.reshape(-1, 4)
        box_confidences = box_confidences.reshape(-1)
        box_class_probs = box_class_probs.reshape(-1, box_class_probs.shape[-1])

        _box_pos = np.where(box_confidences >= self.confidence)
        boxes = boxes[_box_pos]
        box_confidences = box_confidences[_box_pos]
        box_class_probs = box_class_probs[_box_pos]

        class_max_score = np.max(box_class_probs, axis=-1)
        classes = np.argmax(box_class_probs, axis=-1)
        _class_pos = np.where(class_max_score >= self.confidence)

        boxes = boxes[_class_pos]
        classes = classes[_class_pos]
        scores = (class_max_score* box_confidences)[_class_pos]

        return boxes, classes, scores


    def nms_boxes(self, boxes, scores):
        """Suppress non-maximal boxes.

        # Arguments
            boxes: ndarray, boxes of objects.
            scores: ndarray, scores of objects.

        # Returns
            keep: ndarray, index of effective boxes.
        """
        x = boxes[:, 0]
        y = boxes[:, 1]
        w = boxes[:, 2] - boxes[:, 0]
        h = boxes[:, 3] - boxes[:, 1]

        areas = w * h
        order = scores.argsort()[::-1]

        keep = []
        while order.size > 0:
            i = order[0]
            keep.append(i)

            xx1 = np.maximum(x[i], x[order[1:]])
            yy1 = np.maximum(y[i], y[order[1:]])
            xx2 = np.minimum(x[i] + w[i], x[order[1:]] + w[order[1:]])
            yy2 = np.minimum(y[i] + h[i], y[order[1:]] + h[order[1:]])

            w1 = np.maximum(0.0, xx2 - xx1 + 0.00001)
            h1 = np.maximum(0.0, yy2 - yy1 + 0.00001)
            inter = w1 * h1

            ovr = inter / (areas[i] + areas[order[1:]] - inter)
            inds = np.where(ovr <= self.nms_iou)[0]
            order = order[inds + 1]
        keep = np.array(keep)
        return keep

    def postprocess(self, model_outputs):
        boxes, classes, scores = [], [], []
        for input, mask in zip(model_outputs, self.anchors_mask):
            # print(input.shape)
            data = input.reshape(input.shape[0], 3, input.shape[1] // 3, input.shape[2], input.shape[3] )
            # print(data.shape)
            data = np.transpose(data, (0, 3, 4, 1, 2))
            # print(data.shape)
            b, c, s = self.process(data[0], mask, self.anchors, self.input_shape[0])
            b, c, s = self.filter_boxes(b, c, s)
            boxes.append(b)
            classes.append(c)
            scores.append(s)

        boxes = np.concatenate(boxes)
        boxes = self.xywh2xyxy(boxes)
        classes = np.concatenate(classes)
        scores = np.concatenate(scores)

        nboxes, nclasses, nscores = [], [], []
        for c in set(classes):
            inds = np.where(classes == c)
            b = boxes[inds]
            c = classes[inds]
            s = scores[inds]

            keep = self.nms_boxes(b, s)

            nboxes.append(b[keep])
            nclasses.append(c[keep])
            nscores.append(s[keep])

        if not nclasses and not nscores:
            return None, None, None

        boxes = np.concatenate(nboxes)
        classes = np.concatenate(nclasses)
        scores = np.concatenate(nscores)

        if boxes is not None:
            for j in range(len(boxes)):
                boxes[j][0] = (boxes[j][0] - self.dw) / self.ratio[0]
                boxes[j][1] = (boxes[j][1] - self.dh) / self.ratio[1]
                boxes[j][2] = (boxes[j][2] - self.dw) / self.ratio[0]
                boxes[j][3] = (boxes[j][3] - self.dh) / self.ratio[1]

        return boxes, scores, classes
    
    def draw(self, image, boxes, scores, classes):
        if boxes is None: 
            return image

        for i, c in list(enumerate(classes)):
            predicted_class = self.class_names[int(c)]
            box             = boxes[i]
            score           = scores[i]

            left, top, right, bottom = box

            top     = max(0, np.floor(top).astype('int32'))
            left    = max(0, np.floor(left).astype('int32'))

            bottom  = min(image.shape[0], np.floor(bottom).astype('int32'))
            right   = min(image.shape[1], np.floor(right).astype('int32'))

            label = '{} {:.2f}'.format(predicted_class, score)
            # print(label, top, left, bottom, right)
            
            cv2.rectangle(image, (left, top), (right, bottom), self.colors[int(c)], 6)
            cv2.putText(image, label, (left, top - 6),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        2, self.colors[int(c)], 6)

        return image
