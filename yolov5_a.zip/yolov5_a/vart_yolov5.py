from ctypes import *
from typing import List
import os
import cv2
import time
import argparse
import numpy as np
from tqdm import tqdm
import xir
import vart

import sys
from v5prepost import PrePost

def make_parser():
    parser = argparse.ArgumentParser("Yolov5 Demo !")
    parser.add_argument(
        "--model_path", default="model_data/yolov5.xmodel", help="path to model"
    )

    parser.add_argument(
        "--classes_path", default="model_data/classes.txt", help="path to classes"
    )

    parser.add_argument(
        "--anchors_path", default="model_data/anchors.txt", help="path to anchors"
    )

    parser.add_argument(
        "--data_path", default="data", help="path to images"
    )

    parser.add_argument(
        "--save_path", default="out", help="path to save quant results"
    )

    parser.add_argument("--tsize", default=640, type=int, help="test img size")
    parser.add_argument("--confidence", default=0.5, type=float, help="confidence threshold")
    parser.add_argument("--nms_iou", default=0.45, type=float, help="nms_iou")

    return parser

class YoloV5Vart():
    def __init__(self, 
                 model_path='model_data/yolo5.xmodel',
                 classes_path='model_data/classes.txt', 
                 anchors_path='model_data/anchors.txt',
                 input_shape=[640, 640], 
                 confidence=0.5, 
                 nms_iou=0.45):
        super(YoloV5Vart, self).__init__()

        self.pre_post = PrePost(classes_path=classes_path,
                                anchors_path=anchors_path,
                                input_shape=input_shape,
                                confidence=confidence,
                                nms_iou=nms_iou)
       
        self.ModelInit(model_path)

    """
    obtain dpu subgrah
    """
    def get_child_subgraph_dpu(self, graph: "Graph") -> List["Subgraph"]:
        assert graph is not None, "'graph' should not be None."
        root_subgraph = graph.get_root_subgraph()
        assert (root_subgraph
                is not None), "Failed to get root subgraph of input Graph object."
        if root_subgraph.is_leaf:
            return []
        child_subgraphs = root_subgraph.toposort_child_subgraph()
        assert child_subgraphs is not None and len(child_subgraphs) > 0
        return [
            cs for cs in child_subgraphs
            if cs.has_attr("device") and cs.get_attr("device").upper() == "DPU"
        ]
    
    def InputOutInit(self, runner: "Runner"):
        """get tensor"""
        inputTensors = runner.get_input_tensors()
        input_ndim = tuple(inputTensors[0].dims)
        """prepare batch input/output """
        inputData = np.empty(input_ndim, dtype=np.int8, order="C")
        input_fixpos = inputTensors[0].get_attr("fix_point")
        input_scale = 2**input_fixpos

        outputDatas = []    
        output_scales = []
        outputTensors = runner.get_output_tensors()
        for outputTensor in outputTensors:
            output_ndim = tuple(outputTensor.dims)
            output_fixpos = outputTensor.get_attr("fix_point")
            output_scale = 1 / (2**output_fixpos)
            output_scales.append(output_scale)
            # print(outputTensor.name, output_ndim)
            outputDatas.append(np.empty(output_ndim, dtype=np.int8, order="C"))

        return inputData, outputDatas, input_scale, output_scales, input_ndim

    def ModelInit(self, model_path):
        g = xir.Graph.deserialize(model_path)
        self.subgraphs = self.get_child_subgraph_dpu(g)
        assert len(self.subgraphs) == 1  # only one DPU kernel
        self.dpu_runner = vart.Runner.create_runner(self.subgraphs[0], "run")

        self.inputData, self.outputDatas, self.input_scale, self.output_scales, self.input_ndim = self.InputOutInit(self.dpu_runner)
        #print(self.inputData, self.outputDatas, self.input_scale, self.output_scales, self.input_ndim)

    def Inference(self, image, darw=True):
        """init input image to input buffer """
        # image_shape = np.array(np.shape(image)[0:2])
        time_0 = time.time()
        pre_image = self.pre_post.preprocess(image)

        img = pre_image * self.input_scale
        img = img.astype(np.int8)

        self.inputData[0, ...] = img.reshape(self.input_ndim[1:])

        time_1 = time.time()

        """run with batch """
        job_id = self.dpu_runner.execute_async(self.inputData, self.outputDatas)
        self.dpu_runner.wait(job_id)
        # print("inference success")

        time_2 = time.time()

        output_data0 = self.outputDatas[0].transpose(0, 3, 1, 2)
        output_data1 = self.outputDatas[1].transpose(0, 3, 1, 2)
        output_data2 = self.outputDatas[2].transpose(0, 3, 1, 2)
        output_data0 = np.array(output_data0, dtype='float32') * self.output_scales[0]
        output_data1 = np.array(output_data1, dtype='float32') * self.output_scales[1]
        output_data2 = np.array(output_data2, dtype='float32') * self.output_scales[2]
        
        yolo_outputs = [output_data0, output_data1, output_data2]
        boxes, scores, classes = self.pre_post.postprocess(yolo_outputs)
        # print(boxes, classes, scores)

        time_3 = time.time()
        pre_time = time_1 - time_0
        infer_time = time_2 - time_1
        post_time = time_3 - time_2
        total_time = time_3 - time_0
        print("Pre   time=%.6f ms" % (pre_time*1000))
        print("Infer time=%.6f ms" % (infer_time*1000))
        print("Post  time=%.6f ms" % (post_time*1000))
        print("Total time=%.6f ms" % (total_time*1000))
        
        show_img = image
        if darw:
            show_img = self.pre_post.draw(image, boxes, scores, classes)

        #cv2.putText(show_img, 'Inference       time' + ': '+ str(round(infer_time*1000,2)) +' ms', (0,100), cv2.FONT_HERSHEY_SIMPLEX, 3, (255,255,0), 7)
        #cv2.putText(show_img, 'Pre-processing  time' + ': '+ str(round(pre_time * 1000,2)) + 'ms', (0,250), cv2.FONT_HERSHEY_SIMPLEX, 3, (255,255,0), 7)
        #cv2.putText(show_img, 'Post-processing time' + ': '+ str(round(post_time * 1000,2)) + 'ms', (0,400), cv2.FONT_HERSHEY_SIMPLEX, 3, (255,255,0), 7)
        #cv2.putText(show_img, 'Total           time' + ': '+ str(round(total_time*1000,2)) +' ms', (0,550), cv2.FONT_HERSHEY_SIMPLEX, 3, (255,255,0), 7)
        
        return show_img, boxes, scores, classes

        


def main(args): 
    detector = YoloV5Vart(model_path=args.model_path,
                classes_path=args.classes_path,
                anchors_path=args.anchors_path,
                input_shape=[args.tsize, args.tsize],
                confidence=args.confidence,
                nms_iou=args.nms_iou)

    img_names = os.listdir(args.data_path)
    for img_name in tqdm(img_names):
        image_path  = os.path.join(args.data_path, img_name)
        print(image_path)
        image = cv2.imread(image_path)

        time_start = time.time()

        show_img, boxes, scores, classes = detector.Inference(image)

        time_end = time.time()
        timetotal = time_end - time_start
        # print("Total process time=%.6f seconds" % (timetotal))

        cv2.imwrite(os.path.join(args.save_path, img_name), image)


if __name__ == "__main__":
    args = make_parser().parse_args()

    main(args)
